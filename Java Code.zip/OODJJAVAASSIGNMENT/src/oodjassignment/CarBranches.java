/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oodjassignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class CarBranches extends Cars {
    private String CenterID;
    private String State;
    private String Address;
    private String adminID;
    public CarBranches(){}
    
    public CarBranches(String CID, String State, String ADD)
    {
        this.CenterID = CID;
        this.State = State;
        this.Address = ADD; 
        
    }
    public CarBranches(String CID)
    {
        this.CenterID = CID;
        
    }
    //set method
    public void setCenterID(String CID){this.CenterID  = CID;}
    public void setState(String State){this.State = State;}
    public void setAddress(String ADD){this.Address = ADD;}
    public void setAdminID(String adminID){this.adminID = adminID;}
    //get method
    public String getCenterID(){return this.CenterID;}
    public String getState(){return this.State;}
    public String getAddress(){return this.Address;}
    public String getAdminID(){return this.adminID;}
   
    
    public String AssignVaccine(VStatus preStats, VStatus newStat)
    {
        String previousStats = preStats.toString();
        this.VacStatus = newStat;
        this.VCenterID = this.CenterID;
        String[] vacArr = this.returnFileLine();
        this.fileCleaning();
        this.requestedQuantity = 1;
        this.changingData(vacArr, this.requestedQuantity,previousStats,this.VCenterID);
        return this.VacID;
    }
    
    
    public void RemoveVaccine()
    {
        String previousStats = VStatus.InStock.toString();
        this.VacStatus = VStatus.Available;
        this.VCenterID = this.CenterID;
        int availableQuantity = this.calCenterVacQuantity(this.VacType, this.CenterID);
         /////TRACKING RECORD/////
        ArrayList<AModifyVaccinesTracking> MTrackArr = new ArrayList<>();
        CurrentDateTime cdt = new CurrentDateTime();
        AModifyVaccinesTracking MTrack = new 
                 AModifyVaccinesTracking("",this.adminID,this.VCenterID,ActionType.Remove,TargetType.VCenter,cdt.currentDate(),cdt.currentTime(),"");
         MTrackArr = MTrack.FileRead();
         String trackingID = MTrack.setTrackingIDAuto(MTrackArr.size());
         MTrack.setTrackingID(trackingID);
         String remark = "Remove "+this.requestedQuantity + " of " +this.VacType;
         MTrack.setRemark(remark);
         /////////////////////////////////////////////////
        if(availableQuantity - this.requestedQuantity >= 0)
        {
            
            String[] vacArr = this.returnFileLine();
            this.fileCleaning();
            this.changingData(vacArr, this.requestedQuantity,previousStats,"NULL");
             //////////////////Writing Tracking record/////////////////////////
            MTrack.setRemark(remark);
            MTrackArr.add(MTrack);
            MTrack.FileWrite(MTrackArr);
            ////////////////////////////////////////////
        }else
        {
            JOptionPane.showMessageDialog(null, "You have choose more vaccines than available in-stock","OUTNUMBERED",JOptionPane.WARNING_MESSAGE);
        }
    }
    
    public void AddVaccine() //Adding vaccine to specific center, vaccines get from vaccine werehouse
    {
        String previousStats = VStatus.Available.toString();
       
        this.VacStatus = VStatus.InStock;
        this.VCenterID = this.CenterID;
        this.CenterID = "NULL"; //FOR PREVIOUS MATCHING
        int availableQuantity = this.calVacQuantity(this.VacType, previousStats);
         /////TRACKING RECORD/////
        ArrayList<AModifyVaccinesTracking> MTrackArr = new ArrayList<>();
        CurrentDateTime cdt = new CurrentDateTime();
        AModifyVaccinesTracking MTrack = new 
                 AModifyVaccinesTracking("",this.adminID,this.VCenterID,ActionType.Add,TargetType.VCenter,cdt.currentDate(),cdt.currentTime(),"");
         MTrackArr = MTrack.FileRead();
         String trackingID = MTrack.setTrackingIDAuto(MTrackArr.size());
         MTrack.setTrackingID(trackingID);
         String remark = "Add "+this.requestedQuantity + " of " +this.VacType;
         MTrack.setRemark(remark);
         /////////////////////////////////////////////////
        
        if(availableQuantity - this.requestedQuantity >= 0)
        {
            
            String[] vacArr = this.returnFileLine();
            this.fileCleaning();
            this.changingData(vacArr, this.requestedQuantity,previousStats,this.VCenterID);
            //////////////////Writing Tracking record/////////////////////////
            MTrack.setRemark(remark);
            MTrackArr.add(MTrack);
            MTrack.FileWrite(MTrackArr);
            ////////////////////////////////////////////
           
        }else
        {
            JOptionPane.showMessageDialog(null, "You have choose more vaccines than available in werehouse","OUTNUMBERED",JOptionPane.WARNING_MESSAGE);
        }
    }
    
    public static int calCenterVacQuantity(VType type,String CID) //calculate the quantity of specific center that are in stock
    {
        int VacQuantity = 0;
        File file = new File("Cars.txt");
        try {
            Scanner myReader = new Scanner(file);
            while(myReader.hasNext())
            {
                String[] list = myReader.nextLine().split("\\|");
                if(list[1].equals(type.toString()) && list[2].equals(VStatus.InStock.toString()) && list[3].equals(CID))
                {
                    VacQuantity ++;
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cars.class.getName()).log(Level.SEVERE, null, ex);
        }
        return VacQuantity;
    }
    
    protected int calVacQuantity(VType type, String status) //to Return the specifc vaccines quantity available in the Werehouse
    {
        int VacQuantity = 0;
        File file = new File("Cars.txt");
        try {
            Scanner myReader = new Scanner(file);
            while(myReader.hasNext())
            {
                String[] list = myReader.nextLine().split("\\|");
                if(list[1].equals(type.toString()) && list[2].equals(status))
                {
                    VacQuantity ++;
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cars.class.getName()).log(Level.SEVERE, null, ex);
        }
        return VacQuantity;
    }
    
    private String[] returnFileLine()
    {
        String [] Arr = new String[0];
        File file = new File("Cars.txt");
        //////To take out all data from the txt file
        try {
            Scanner myReader = new Scanner(file);
            while(myReader.hasNextLine())
            {
                Arr = Arrays.copyOf(Arr, Arr.length + 1);
                Arr[Arr.length - 1] = myReader.nextLine();
                
            }
            myReader.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Users.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Arr;
    }
    private void fileCleaning()
    {
        FileWriter fw;
        File file = new File("Cars.txt");
        try {
            fw = new FileWriter(file,false);
            PrintWriter pw = new PrintWriter(fw,false);
            pw.flush();
            pw.close();
            fw.close();
            
        } catch (IOException ex) {
            Logger.getLogger(Users.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void changingData(String [] Arr, int Quantity, String previousStats, String nCID)
    {
        int count = 0;
        for (int i = 0; i < Arr.length; i ++)
        {

            String [] list = Arr[i].split("\\|");

            {
                if(list[1].equals(this.VacType.toString()) && list[2].equals(previousStats) && count < Quantity && list[3].equals(this.CenterID))
                {

                    list[2] = this.VacStatus.toString();
                    list[3] = nCID;
                    this.VacID = list[0];
                    count ++;
                    
                }else
                {
                    continue;
                }
            }
            
            Arr[i] = String.join("|", list);
        }
        FileWriter fw;
        File file = new File("Cars.txt");
        try {
            fw = new FileWriter(file,true);
            PrintWriter pw = new PrintWriter(fw,true);
            for (int i = 0; i < Arr.length;i++)
            {
                pw.println(Arr[i]);
            }
            
            fw.close();
            if(this.VacStatus.equals(VStatus.InStock) && previousStats.equals(VStatus.Available.toString()))
            {
                JOptionPane.showMessageDialog(null,  "Succesfully insert " + Quantity + " of " + this.VacType.toString());
            }else if(this.VacStatus.equals(VStatus.Available))
            {
                JOptionPane.showMessageDialog(null,  "Succesfully Remove " + Quantity + " of " + this.VacType.toString() + " from the stock");
            }
            
        } catch (IOException ex) {
            Logger.getLogger(Users.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    public  static String[] showCentersAddress(String CID)
    {
        String [] AddressArr = new String[2];
        File file = new File("Branches.txt");
        try {
            Scanner myReader = new Scanner(file);
            while(myReader.hasNext())
            {
                
                String line [] = myReader.nextLine().split("\\|");
                if (CID.equals(line[0]))
                {
                    
                    AddressArr[0] = line[1];
                    AddressArr[1] = line[2];
                    break;
                }           
            }
        
            
            
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CarBranches.class.getName()).log(Level.SEVERE, null, ex);
        }
        return AddressArr;
    }
    
    public static String[] VCenterViewAll()
    {
        int count = 0;
        String [] lineArray = new String[0];
        try 
        {
            File file = new File("Branches.txt");
            Scanner myReader = new Scanner(file);
            while(myReader.hasNextLine())
            {
                String line = myReader.nextLine(); 
                lineArray = Arrays.copyOf(lineArray, count + 1);
                lineArray[count] = line;
                
                count += 1;
            }
            
        } 
        catch (FileNotFoundException ex) 
        {
            Logger.getLogger(Users.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lineArray;
    }
}





